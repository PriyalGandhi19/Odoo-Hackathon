from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import *

class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_verified', 'is_pro_member', 'total_swaps', 'rating')
    list_filter = ('is_verified', 'is_pro_member', 'is_staff', 'is_superuser', 'is_active')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    
    fieldsets = UserAdmin.fieldsets + (
        ('Profile Info', {
            'fields': ('location', 'profile_photo', 'bio', 'visibility', 'is_verified', 'is_pro_member')
        }),
        ('Stats', {
            'fields': ('points', 'rating', 'total_swaps', 'is_banned')
        }),
    )

admin.site.register(User, CustomUserAdmin)

@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'is_approved', 'created_at')
    list_filter = ('category', 'is_approved')
    search_fields = ('name', 'category')

@admin.register(UserSkillOffered)
class UserSkillOfferedAdmin(admin.ModelAdmin):
    list_display = ('user', 'skill', 'skill_level', 'created_at')
    list_filter = ('skill_level', 'skill__category')
    search_fields = ('user__username', 'skill__name')

@admin.register(UserSkillWanted)
class UserSkillWantedAdmin(admin.ModelAdmin):
    list_display = ('user', 'skill', 'created_at')
    list_filter = ('skill__category',)
    search_fields = ('user__username', 'skill__name')

@admin.register(SwapRequest)
class SwapRequestAdmin(admin.ModelAdmin):
    list_display = ('requester', 'recipient', 'requester_skill', 'recipient_skill', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('requester__username', 'recipient__username')

@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display = ('rater', 'rated', 'rating', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('rater__username', 'rated__username')

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'recipient', 'is_read', 'created_at')
    list_filter = ('is_read', 'created_at')
    search_fields = ('sender__username', 'recipient__username')

@admin.register(Achievement)
class AchievementAdmin(admin.ModelAdmin):
    list_display = ('name', 'points_required', 'created_at')
    search_fields = ('name',)
