from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'skillswap'

urlpatterns = [
    # Main pages
    path('', views.IndexView.as_view(), name='index'),
    path('browse/', views.BrowseView.as_view(), name='browse'),
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('profile/<str:username>/', views.ProfileDetailView.as_view(), name='profile_detail'),
    path('my-swaps/', views.MySwapsView.as_view(), name='my_swaps'),
    path('messages/', views.MessagesView.as_view(), name='messages'),
    path('leaderboard/', views.LeaderboardView.as_view(), name='leaderboard'),
    
    # AJAX endpoints
    path('api/users/', views.UsersAPIView.as_view(), name='api_users'),
    path('api/swap-request/', views.SwapRequestAPIView.as_view(), name='api_swap_request'),
    path('api/messages/', views.MessagesAPIView.as_view(), name='api_messages'),
    
    # Authentication
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', views.RegisterView.as_view(), name='register'),
]
