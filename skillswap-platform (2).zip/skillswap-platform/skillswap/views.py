from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView, CreateView, ListView
from django.contrib.auth import login
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q, Avg, Count
from django.views import View
from django.core.paginator import Paginator
from .models import *
from .forms import UserRegistrationForm
import json

class IndexView(LoginRequiredMixin, TemplateView):
    template_name = 'index.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Get skill matches
        user_wanted_skills = user.skills_wanted.values_list('skill_id', flat=True)
        user_offered_skills = user.skills_offered.values_list('skill_id', flat=True)
        
        matches = User.objects.filter(
            skills_offered__skill_id__in=user_wanted_skills,
            skills_wanted__skill_id__in=user_offered_skills
        ).exclude(id=user.id).distinct()[:2]
        
        context['matches'] = matches
        context['recent_activity'] = self.get_recent_activity(user)
        context['upcoming_sessions'] = Session.objects.filter(
            swap_request__requester=user
        ).filter(status='scheduled').order_by('session_date', 'start_time')[:2]
        
        return context
    
    def get_recent_activity(self, user):
        # Simulate recent activity
        return [
            {
                'type': 'completed',
                'message': 'Swap completed with Maria Garcia',
                'detail': 'Spanish lesson - 2 hours ago',
                'icon': 'fas fa-check-circle',
                'color': 'green'
            },
            {
                'type': 'message',
                'message': 'New message from Sarah Miller',
                'detail': 'About upcoming web dev session - 4 hours ago',
                'icon': 'fas fa-message',
                'color': 'blue'
            }
        ]

class BrowseView(ListView):
    model = User
    template_name = 'browse.html'
    context_object_name = 'users'
    paginate_by = 12
    
    def get_queryset(self):
        queryset = User.objects.filter(is_active=True, is_banned=False)
        
        # Search functionality
        search = self.request.GET.get('search')
        if search:
            queryset = queryset.filter(
                Q(username__icontains=search) |
                Q(first_name__icontains=search) |
                Q(last_name__icontains=search) |
                Q(skills_offered__skill__name__icontains=search) |
                Q(skills_wanted__skill__name__icontains=search)
            ).distinct()
        
        # Filter by category
        category = self.request.GET.get('category')
        if category:
            queryset = queryset.filter(skills_offered__skill__category=category)
        
        # Filter by skill level
        level = self.request.GET.get('level')
        if level:
            queryset = queryset.filter(skills_offered__skill_level=level)
        
        return queryset.exclude(id=self.request.user.id if self.request.user.is_authenticated else None)

class ProfileView(LoginRequiredMixin, TemplateView):
    template_name = 'profile.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        context['user_skills_offered'] = user.skills_offered.select_related('skill')
        context['user_skills_wanted'] = user.skills_wanted.select_related('skill')
        context['user_availability'] = user.availability.all()
        context['user_achievements'] = user.achievements.select_related('achievement')
        context['recent_reviews'] = Rating.objects.filter(rated=user).order_by('-created_at')[:3]
        
        return context

class ProfileDetailView(TemplateView):
    template_name = 'profile_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        username = kwargs.get('username')
        profile_user = get_object_or_404(User, username=username)
        
        context['profile_user'] = profile_user
        context['user_skills_offered'] = profile_user.skills_offered.select_related('skill')
        context['user_skills_wanted'] = profile_user.skills_wanted.select_related('skill')
        context['recent_reviews'] = Rating.objects.filter(rated=profile_user).order_by('-created_at')[:5]
        
        return context

class MySwapsView(LoginRequiredMixin, TemplateView):
    template_name = 'my-swaps.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        context['active_swaps'] = SwapRequest.objects.filter(
            Q(requester=user) | Q(recipient=user),
            status__in=['accepted', 'active']
        ).select_related('requester', 'recipient', 'requester_skill', 'recipient_skill')
        
        context['pending_swaps'] = SwapRequest.objects.filter(
            Q(requester=user) | Q(recipient=user),
            status='pending'
        ).select_related('requester', 'recipient', 'requester_skill', 'recipient_skill')
        
        context['completed_swaps'] = SwapRequest.objects.filter(
            Q(requester=user) | Q(recipient=user),
            status='completed'
        ).select_related('requester', 'recipient', 'requester_skill', 'recipient_skill')
        
        return context

class MessagesView(LoginRequiredMixin, TemplateView):
    template_name = 'messages.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['messages'] = Message.objects.filter(
            Q(sender=self.request.user) | Q(recipient=self.request.user)
        ).order_by('-created_at')
        return context

class LeaderboardView(TemplateView):
    template_name = 'leaderboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['top_users'] = User.objects.filter(
            is_active=True, is_banned=False
        ).order_by('-total_swaps', '-rating')[:10]
        return context

class RegisterView(CreateView):
    form_class = UserRegistrationForm
    template_name = 'registration/register.html'
    
    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        messages.success(self.request, 'Registration successful!')
        return redirect('skillswap:index')

# API Views
class UsersAPIView(View):
    def get(self, request):
        users = User.objects.filter(is_active=True, is_banned=False)
        
        # Apply filters
        search = request.GET.get('search')
        if search:
            users = users.filter(
                Q(username__icontains=search) |
                Q(first_name__icontains=search) |
                Q(skills_offered__skill__name__icontains=search)
            ).distinct()
        
        users_data = []
        for user in users[:20]:  # Limit results
            users_data.append({
                'id': user.id,
                'name': f"{user.first_name} {user.last_name}",
                'username': user.username,
                'location': user.location,
                'rating': float(user.rating),
                'total_swaps': user.total_swaps,
                'is_verified': user.is_verified,
                'is_pro_member': user.is_pro_member,
            })
        
        return JsonResponse({'users': users_data})

class SwapRequestAPIView(LoginRequiredMixin, View):
    def post(self, request):
        data = json.loads(request.body)
        
        swap_request = SwapRequest.objects.create(
            requester=request.user,
            recipient_id=data['recipient_id'],
            requester_skill_id=data['requester_skill_id'],
            recipient_skill_id=data['recipient_skill_id'],
            message=data.get('message', '')
        )
        
        return JsonResponse({
            'success': True,
            'message': 'Swap request sent successfully!'
        })

class MessagesAPIView(LoginRequiredMixin, View):
    def get(self, request):
        messages = Message.objects.filter(
            Q(sender=request.user) | Q(recipient=request.user)
        ).order_by('-created_at')
        
        messages_data = []
        for msg in messages[:50]:
            messages_data.append({
                'id': msg.id,
                'sender': msg.sender.username,
                'recipient': msg.recipient.username,
                'message': msg.message,
                'is_read': msg.is_read,
                'created_at': msg.created_at.isoformat()
            })
        
        return JsonResponse({'messages': messages_data})
    
    def post(self, request):
        data = json.loads(request.body)
        
        message = Message.objects.create(
            sender=request.user,
            recipient_id=data['recipient_id'],
            message=data['message'],
            swap_request_id=data.get('swap_request_id')
        )
        
        return JsonResponse({
            'success': True,
            'message': 'Message sent successfully!'
        })
