#!/bin/bash

# Django SkillSwap Setup Instructions

echo "Setting up Django SkillSwap Project..."

# 1. Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create MySQL database
echo "Please create a MySQL database named 'skillswap' and update the database settings in settings.py"

# 4. Run migrations
python manage.py makemigrations
python manage.py migrate

# 5. Create superuser
python manage.py createsuperuser

# 6. Populate sample data
python scripts/populate_data.py

# 7. Collect static files (if needed in production)
python manage.py collectstatic --noinput

# 8. Run development server
echo "Setup complete! Run 'python manage.py runserver' to start the development server"
